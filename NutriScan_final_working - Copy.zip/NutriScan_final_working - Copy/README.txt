Step 1: Install Dependencies

Navigate to the barcode_scanner_run folder and run the following command in the terminal:

npm install
Step 2: Build the Neural Network Model

Open the designated folder (referred to here as "Folder A") intended for creating the neural network model.
Within this folder, locate and execute the build_neural_network file to generate the model.
Once the model is successfully created, move it to the main folder.
Step 3: Run Python Scripts

Execute the following Python files:

fetch_product_info_run.py
predict_food_run.py


Step 4: Launch the Barcode Scanner

In the barcode_scanner_run folder, start the application by running:

npm start
Open the Expo app on your mobile device.

Scan the displayed QR code to access and run the application.