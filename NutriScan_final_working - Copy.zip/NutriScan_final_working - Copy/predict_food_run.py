# from flask import Flask, request, jsonify
# import requests
# import numpy as np
# import tensorflow as tf

# app = Flask(__name__)

# class BarcodeFoodLabelling:
#     def __init__(self, api_url, model_path):
#         self.api_url = api_url
#         self.model_path = model_path
#         self.product_data = {}

#     def get_information_by_barcode(self, barcode):
#         response = requests.get(f"{self.api_url}?barcode={barcode}")
#         if response.status_code == 200:
#             self.product_data = response.json()
#             return True
#         return False

#     def format_incoming_data(self):
#         data = self.product_data
#         return {
#             "energy": data.get("energy-kcal_100g", 0) / 1000,
#             "carbohydrates": data.get("carbohydrates_100g", 0) / 100,
#             "sugars": data.get("sugars_100g", 0) / 100,
#             "fat": data.get("fat_100g", 0) / 100,
#             "saturated": data.get("saturated-fat_100g", 0) / 100,
#             "fiber": data.get("fiber_100g", 0) / 10,
#             "proteins": data.get("proteins_100g", 0) / 100,
#             "salt": data.get("salt_100g", 0) / 10,
#             "sodium": data.get("sodium_100g", 0) / 10,
#         }

#     def run_inference(self):
#         model = tf.keras.models.load_model(self.model_path)
#         data = self.format_incoming_data()
#         input_data = np.array([[
#             data["energy"], data["carbohydrates"], data["sugars"],
#             data["fat"], data["saturated"], data["fiber"],
#             data["proteins"], data["salt"], data["sodium"]
#         ]], dtype=np.float32)
        
#         output_data = model.predict(input_data)
#         class_names = ["Nutritious", "Healthy", "Less Healthy", "Unhealthy"]
#         prediction = class_names[np.argmax(output_data)]
#         return prediction

# @app.route('/predict', methods=['POST'])
# def predict():
#     barcode = request.json.get('barcode')
#     api_url = "http://localhost:5001/product_info"  # Ensure this URL is correct and reachable
#     model_path = "ANN_Nutrient_Profiling.h5"
#     labelling = BarcodeFoodLabelling(api_url, model_path)

#     if labelling.get_information_by_barcode(barcode):
#         prediction = labelling.run_inference()
#         return jsonify({'prediction': prediction})
#     else:
#         return jsonify({'error': 'Barcode not found or error retrieving data'}), 404

# if __name__ == '__main__':
#     app.run(debug=True, port=5000)



from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import numpy as np
import tensorflow as tf

app = Flask(__name__)
CORS(app)  # Enable CORS

class BarcodeFoodLabelling:
    def __init__(self, api_url, model_path):
        self.api_url = api_url
        self.model_path = model_path
        self.product_data = {}

    def get_information_by_barcode(self, barcode):
        response = requests.get(f"{self.api_url}?barcode={barcode}")
        if response.status_code == 200:
            self.product_data = response.json()
            return True
        return False

    def format_incoming_data(self):
        data = self.product_data
        return {
            "energy": data.get("energy-kcal_100g", 0) / 1000,
            "carbohydrates": data.get("carbohydrates_100g", 0) / 100,
            "sugars": data.get("sugars_100g", 0) / 100,
            "fat": data.get("fat_100g", 0) / 100,
            "saturated": data.get("saturated-fat_100g", 0) / 100,
            "fiber": data.get("fiber_100g", 0) / 10,
            "proteins": data.get("proteins_100g", 0) / 100,
            "salt": data.get("salt_100g", 0) / 10,
            "sodium": data.get("sodium_100g", 0) / 10,
        }

    def run_inference(self):
        model = tf.keras.models.load_model(self.model_path)
        data = self.format_incoming_data()
        input_data = np.array([[
            data["energy"], data["carbohydrates"], data["sugars"],
            data["fat"], data["saturated"], data["fiber"],
            data["proteins"], data["salt"], data["sodium"]
        ]], dtype=np.float32)
        
        output_data = model.predict(input_data)
        class_names = ["Nutritious", "Healthy", "Less Healthy", "Unhealthy"]
        prediction = class_names[np.argmax(output_data)]
        return prediction

@app.route('/predict', methods=['POST'])
def predict():
    barcode = request.json.get('barcode')
    api_url = "http://localhost:5001/product_info"  # Use the correct URL if needed
    model_path = "ANN_Nutrient_Profiling.h5"
    labelling = BarcodeFoodLabelling(api_url, model_path)

    if labelling.get_information_by_barcode(barcode):
        prediction = labelling.run_inference()
        return jsonify({'prediction': prediction})
    else:
        return jsonify({'error': 'Barcode not found or error retrieving data'}), 404

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

