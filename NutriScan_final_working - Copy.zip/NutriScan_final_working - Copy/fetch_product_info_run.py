from flask import Flask, request, jsonify
import requests
import json

app = Flask(__name__)

@app.route('/product_info', methods=['GET'])
def product_info():
    barcode = request.args.get('barcode')
    if not barcode:
        return jsonify({"error": "Barcode is required"}), 400

    url = f"https://world.openfoodfacts.org/api/v0/product/{barcode}.json"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        if data.get('status_verbose') == 'product not found':
            return jsonify({"error": "Product not found"}), 404

        product = data.get('product', {})
        nutriments = product.get('nutriments', {})
        result = {
            "name": product.get("brands", " "),
            "type": product.get("product_name", " "),
            "quantity": product.get("product_quantity", 100),
            "serving_quantity": product.get("serving_quantity", 100),
            "energy-kcal_100g": nutriments.get('energy-kcal_100g', 0),
            "energy-kcal_serving": nutriments.get('energy-kcal_serving', nutriments.get('energy-kcal_100g', 0)),
            "carbohydrates_100g": nutriments.get('carbohydrates_100g', 0),
            "carbohydrates_serving": nutriments.get('carbohydrates_serving', nutriments.get('carbohydrates_100g', 0)),
            "sugars_100g": nutriments.get('sugars_100g', 0),
            "sugars_serving": nutriments.get('sugars_serving', nutriments.get('sugars_100g', 0)),
            "fat_100g": nutriments.get('fat_100g', 0),
            "fat_serving": nutriments.get('fat_serving', nutriments.get('fat_100g', 0)),
            "saturated-fat_100g": nutriments.get('saturated-fat_100g', 0),
            "saturated-fat_serving": nutriments.get('saturated-fat_serving', nutriments.get('saturated-fat_100g', 0)),
            "fruits_vegetables_100g": nutriments.get('fruits-vegetables-nuts-estimate-from-ingredients_100g', 0),
            "fiber_100g": nutriments.get('fiber_100g', 0),
            "fiber_serving": nutriments.get('fiber_serving', 0),
            "proteins_100g": nutriments.get('proteins_100g', 0),
            "proteins_serving": nutriments.get('proteins_serving', nutriments.get('proteins_100g', 0)),
            "salt_100g": nutriments.get('salt_100g', 0),
            "salt_serving": nutriments.get('salt_serving', nutriments.get('salt_100g', 0)),
            "sodium_100g": nutriments.get('sodium_100g', 0),
            "sodium_serving": nutriments.get('sodium_serving', nutriments.get('sodium_100g', 0)),
            "calcium_100g": nutriments.get('calcium_100g', 0),
            "calcium_serving": nutriments.get('calcium_serving', 0),
            "nutri_score": product.get('nutriscore_data', {}).get('score', 0),
            "nutri_grade": product.get('nutriscore_data', {}).get('grade', "Undefined"),
            "co2_total": product.get('ecoscore_data', {}).get('agribalyse', {}).get('co2_total', 1),
            "ef_total": product.get('ecoscore_data', {}).get('agribalyse', {}).get('ef_total', 0.25)
        }
        return jsonify(result)
    
    return jsonify({"error": "Failed to retrieve product data"}), 500

if __name__ == '__main__':
    app.run(port=5001, debug=True)
