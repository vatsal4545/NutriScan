import requests
import numpy as np
import tensorflow as tf

class BarcodeFoodLabelling:
    def __init__(self, api_url, model_path):
        self.api_url = api_url
        self.model_path = model_path
        self.product_data = {}

    def get_information_by_barcode(self, barcode):
        response = requests.get(f"{self.api_url}?barcode={barcode}")
        if response.status_code == 200:
            self.product_data = response.json()
            return True
        return False

    def format_incoming_data(self):
        data = self.product_data
        return {
            "energy": data.get("energy-kcal_100g", 0) / 1000,
            "carbohydrates": data.get("carbohydrates_100g", 0) / 100,
            "sugars": data.get("sugars_100g", 0) / 100,
            "fat": data.get("fat_100g", 0) / 100,
            "saturated": data.get("saturated-fat_100g", 0) / 100,
            "fiber": data.get("fiber_100g", 0) / 10,
            "proteins": data.get("proteins_100g", 0) / 100,
            "salt": data.get("salt_100g", 0) / 10,
            "sodium": data.get("sodium_100g", 0) / 10,
        }

    def run_inference(self):
        model = tf.keras.models.load_model(self.model_path)
        data = self.format_incoming_data()
        input_data = np.array([[
            data["energy"], data["carbohydrates"], data["sugars"],
            data["fat"], data["saturated"], data["fiber"],
            data["proteins"], data["salt"], data["sodium"]
        ]], dtype=np.float32)
        
        output_data = model.predict(input_data)
        class_names = ["Nutritious", "Healthy", "Less Healthy", "Unhealthy"]
        prediction = class_names[np.argmax(output_data)]
        return prediction

def main():
    api_url = "http://localhost:5001/product_info"
    model_path = "ANN_Nutrient_Profiling.h5"
    labelling = BarcodeFoodLabelling(api_url, model_path)

    while True:
        barcode = input("\r\nWaiting for reading new barcodes...\r\n")
        if barcode:
            if labelling.get_information_by_barcode(barcode):
                prediction = labelling.run_inference()
                print("\r\n--------------\r\n")
                print("Prediction => " + prediction)
                print("\r\n--------------\r\n")
            else:
                print("Barcode not found or error retrieving data")

if __name__ == '__main__':
    main()
